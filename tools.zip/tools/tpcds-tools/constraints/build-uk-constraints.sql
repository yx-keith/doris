alter table customer add constraint c_uk unique (c_customer_id);
