alter table item add constraint i_pk primary key (i_item_sk);
alter table customer add constraint c_pk primary key (c_customer_sk);
