insert into hive_dlf_db.types values(123,34,3455,34.667754,"wastxali",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23");
insert into hive_dlf_db.types_one_part values(604,376,234,123.478,"aswwas",234.1234,"a23f","wsd",false,"2023-04-23 21:23:34.123","2023-04-23","2023-04-22");
insert into hive_dlf_db.types_one_part values(223,22,234,234.500,"awsali",234.1234,"a23f","1234vb",true,"2023-04-22 21:21:34.123","2023-04-21","2023-04-24");
insert into hive_dlf_db.types_multi_part values(1234,346,234,123.65567,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-20","2023-04-21 19:23:34.123","2023-04-19");
insert into hive_dlf_db.types_multi_part values(3212343,34,234,123.730,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-20","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_dlf_db.types_multi_part values(355,22,990,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-21","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_dlf_db.types_multi_part values(23675,22,986,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-25","2023-04-21 19:23:34.123","2023-04-24");