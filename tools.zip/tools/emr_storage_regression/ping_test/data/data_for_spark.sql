insert into spark_hms_db.types values(123,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23");
insert into spark_hms_db.types_one_part values(223,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23 21:23:34","2023-04-23");
insert into spark_hms_db.types_one_part values(223,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23 21:23:34","2023-04-23");
insert into spark_hms_db.types_multi_part values(323,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",true,"2023-04-23","2023-04-23 21:23:34.123","2023-04-23");
insert into spark_hms_db.types_multi_part values(323,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",true,"2023-04-23","2023-04-23 21:23:34.123","2023-04-23");
insert into spark_hms_db.types_multi_part values(323,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",true,"2023-04-23","2023-04-23 21:23:34.123","2023-04-23");

--insert into iceberg.spark_iceberg_db_hms.types values(123,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23");
--insert into iceberg.spark_iceberg_db_hms.types_one_part values(223,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23","2023-04-23");
--insert into iceberg.spark_iceberg_db_hms.types_multi_part values(323,22,234,123.324235,"sawer",234.1234,"a23f","1234vb",true,"2023-04-23","2023-04-23 21:23:34.123","2023-04-23");
