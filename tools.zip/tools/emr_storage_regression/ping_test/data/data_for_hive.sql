insert into hive_hms_db.types values(1123,5126,51,4534.63463,"wastxali",235.2351,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23");
insert into hive_hms_db.types_one_part values(23621,23,234,345.12512356,"aswwas",525.2352,"a23f","wsd",false,"2023-04-23 21:23:34.123","2023-04-23","2023-04-22");
insert into hive_hms_db.types_one_part values(11625,62,234,2347.6236,"awsali",546.2342,"a23f","1234vb",true,"2023-04-22 21:21:34.123","2023-04-21","2023-04-24");
insert into hive_hms_db.types_multi_part values(123,66,234,13.1242,"hwaws",3463.4363,"a23f","1234vb",true,"2023-04-20","2023-04-21 19:23:34.123","2023-04-19");
insert into hive_hms_db.types_multi_part values(324,77,234,123.163446,"hwaws",345.3413,"a23f","1234vb",true,"2023-04-20","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_hms_db.types_multi_part values(423,909,234,123657.512,"hwaws",234.2363,"a23f","1234vb",true,"2023-04-21","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_hms_db.types_multi_part values(343,712,234,1234.21451,"hwaws",3564.8945,"a23f","1234vb",true,"2023-04-25","2023-04-21 19:23:34.123","2023-04-24");

insert into hive_iceberg_db_hms.types values(123,22,234,123.324235,"wsawh",234.1234,"a23f","1234vb",false,"2023-04-23 21:23:34.123","2023-04-23");
insert into hive_iceberg_db_hms.types_one_part values(223,22,234,123.324235,"aswwas",234.1234,"a23f","wsd",false,"2023-04-23 21:23:34.123","2023-04-23","2023-04-22");
insert into hive_iceberg_db_hms.types_one_part values(223,22,234,123.324235,"awsali",234.1234,"a23f","1234vb",true,"2023-04-22 21:21:34.123","2023-04-21","2023-04-24");
insert into hive_iceberg_db_hms.types_multi_part values(323,22,234,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-20","2023-04-21 19:23:34.123","2023-04-19");
insert into hive_iceberg_db_hms.types_multi_part values(323,22,234,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-20","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_iceberg_db_hms.types_multi_part values(323,22,234,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-21","2023-04-22 20:23:34.123","2023-04-22");
insert into hive_iceberg_db_hms.types_multi_part values(323,22,234,123.324235,"hwaws",234.1234,"a23f","1234vb",true,"2023-04-25","2023-04-21 19:23:34.123","2023-04-24");
