select * from spark_hms_db.types;
select * from spark_hms_db.types_one_part;
select * from spark_hms_db.types_multi_part;

select * from hive_hms_db.types;
select * from hive_hms_db.types_one_part;
select * from hive_hms_db.types_multi_part;

select * from spark_iceberg_db_hms.types;
select * from spark_iceberg_db_hms.types_one_part;
select * from spark_iceberg_db_hms.types_multi_part;

select * from hive_iceberg_db_hms.types;
select * from hive_iceberg_db_hms.types_one_part;
select * from hive_iceberg_db_hms.types_multi_part;

select * from hive_dlf_db.types;
select * from hive_dlf_db.types_one_part;
select * from hive_dlf_db.types_multi_part;

select * from hive_iceberg_db_dlf.types;
select * from hive_iceberg_db_dlf.types_one_part;
select * from hive_iceberg_db_dlf.types_multi_part;
